export class FoodNutrients{

    number: String | undefined;
    name: String | undefined;
    amount: number | undefined;
    unitName: String | undefined;
    derivationCode: String | undefined;
    derivationDescription: String | undefined
 
}
