export class RemoveFavorited{
    username:String|undefined;
    fdcId:number|undefined;
}